export interface ISize {
  width: number;
  height: number;
}

export interface IObject {
  [key: string]: any;
}
