<footer class="footer">
  <div class="container">
    <span class="copyright">
    © 2020 Berry app. All rights reserved.
    </span>
  </div>
</footer>
